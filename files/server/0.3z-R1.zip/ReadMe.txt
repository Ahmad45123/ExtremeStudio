This is an ExtremeStudio project.

The files and folders in the project's root folder should never be renamed.. They are used by the program.

Thanks for using ExtremeStudio :)